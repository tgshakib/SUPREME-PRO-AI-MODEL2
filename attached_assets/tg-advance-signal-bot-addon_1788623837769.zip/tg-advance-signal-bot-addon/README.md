# TG Advance Signal Generator — Bot Add-on

This is a standalone copy of the Telegram signal bot. It is designed to run beside an existing lifetime bot as a second Telegram bot process.

## Included

- User onboarding and settings
- Real-market and OTC market selection
- Quotex, Pocket Option, IQ Option, Olymp Trade, and real-market adapters
- Signal count options and 1-hour block mode
- CALL, PUT, and MIX direction flows
- Strategy selection and timeframe/timezone settings
- Package/paywall flow
- Binance Pay, USDT TRC20, BTC, BNB BEP20, ETH ERC20, and Solana payment instructions
- Payment screenshot submission and admin approve/reject controls
- Admin assessment and user-management controls
- Compiled `dist/index.mjs` plus the complete TypeScript source

## Run beside the lifetime bot

1. Create a **different Telegram bot** with @BotFather and copy its token.
2. Extract this folder on the same server or Replit project as the lifetime bot.
3. Copy `.env.example` to `.env`.
4. Set:
   - `TELEGRAM_BOT_TOKEN` to the second bot token.
   - `BOT_ADMIN_ID` to the same numeric admin ID used by the lifetime bot.
   - `PORT` to a different unused port if both services share one machine.
5. Install and start:

```bash
pnpm install
pnpm start
```

To rebuild from source after editing:

```bash
pnpm run build
pnpm start
```

## Important

- Never use the same Telegram bot token in two running processes.
- The admin ID can be shared; the Telegram bot token must not be shared.
- Do not commit `.env` or paste the token into chat.
- User session state is held in memory, so active in-progress flows reset when this process restarts.
- The included adapters use algorithmic fallback data where official broker APIs are unavailable. This bot cannot guarantee wins, 95–99% accuracy, or risk-free profit. Always validate signals before trading.

## Health check

After startup, open:

```text
http://127.0.0.1:<PORT>/api/healthz
```

A working server returns `{"status":"ok"}`.
